# salon_management_system
Project focus on scalable cloud programming
