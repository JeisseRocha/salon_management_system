import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jeisse',
    application_name='payment-management',
    app_uid='X2NcvHBkKJVyvWxr8Q',
    org_uid='6fab44b3-c11b-4163-b09f-a88dcc38ec7f',
    deployment_uid='b1ac5dd5-34c0-46fb-b026-a27ef7aa4e6b',
    service_name='payment-management',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'payment-management-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
